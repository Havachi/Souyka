<?php
$language["LIST_TITLE"] = "Populair Zelfstudie";
$language["NOTIFY_NO_RESULT"] = "Geen Resultaten Gevonden";
?>