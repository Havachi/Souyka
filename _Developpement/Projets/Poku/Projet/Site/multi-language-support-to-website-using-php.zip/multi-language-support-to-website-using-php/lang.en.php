<?php
$language['LIST_TITLE'] = 'Popular Tutorial';
$language["NOTIFY_NO_RESULT"] = "No Results Found";
?>